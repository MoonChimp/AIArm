/*===================
header sticky js
=======================*/
window.addEventListener('scroll', function () {
    var header = document.querySelector('header');

    if (window.pageYOffset > 500) {
        header.classList.add('sticky');
    } else {
        header.classList.remove('sticky');
    }
});
